<?php

namespace App\Infrastructure\Controllers;

abstract class Controller
{
    //
}
